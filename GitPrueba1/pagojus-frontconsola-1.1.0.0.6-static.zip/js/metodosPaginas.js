const selectorPagina = "#selectorPagina";
const idSort = "#idSort";
const localizadorSort = "#localizadorSort";
const nombreSort = "#nombreSort";
const importeSort = "#importeSort";
const nrcSort = "#nrcSort";
const fhSort = "#fhSort";
const estadoSort = "#estadoSort";
const pagadorSort = "#pagadorSort";
const razonSocialSort = "#razonSocialSort";

const primeraPagina = "#primeraPagina";
const siguientePagina = "#siguientePagina";
const anteriorPagina = "#anteriorPagina";
const ultimaPagina = "#ultimaPagina";
const totalRegistros = "#totalRegistros";

const nrcTasa = "#nrcTasa";
const nrcTasaCorregido = "#nrcTasaCorregido";
const expediente = "#expediente";
const expedienteCorregido = "#expedienteCorregido";
const estadoTasa = "#estadoTasa";
const estadoTasaCorregido = "#estadoTasaCorregido";

const btnVolver = "#btnVolver";
const btnEditar = "#btnEditar";

const btnExportExcelCies = "#btnExportExcelCies";
const btnExportExcel = "#btnExportExcel";
const btnDetalle = "#btnDetalle";
const volver = "#contadorHistorialVolver";

const detalleBusquedaTasaForm = "#detalleBusquedaTasaForm";

const usrPassError = "#usrPassError";

const codAplicacion = "#codAplicacion";
const ASC_ARROW = '▲';
const DESC_ARROW = '▼';


$(document).ready(function () {
  //Ir a la pagina de la tabla seleccionada-------------------------------------------------------
  $(selectorPagina).on('change', function () {
    cambiarPagina(1, this.value);
  });

  $(primeraPagina).on('click', function () {
    cambiarPagina(1, $(selectorPagina).val());
  });

  $(siguientePagina).on('click', function () {
    var url = new URL(window.location.href);
    var params = url.searchParams;
    var pagParam = Number(params.get('numPag'));
    var totalPaginas = Number($(totalRegistros).text()) / Number($(selectorPagina).val());
    totalPaginas = Math.trunc(totalPaginas) + 1;
    if(pagParam == null || pagParam == 0) {
      pagParam = 1;
    }
    if(pagParam == totalPaginas) {
      return;
    }
    cambiarPagina(pagParam + 1, $(selectorPagina).val());
  });

  $(anteriorPagina).on('click', function () {
    var totalPaginas = Number($(totalRegistros).text()) / Number($(selectorPagina).val());
     totalPaginas = Math.trunc(totalPaginas) + 1;
     if(totalPaginas === 1){
       return;
     }
    var url = new URL(window.location.href);
    var params = url.searchParams;
    var pagParam = Number(params.get('numPag'));
    if(pagParam == null || pagParam == 1) {
      return;
    }
    cambiarPagina(pagParam - 1, $(selectorPagina).val());
  });

  $(ultimaPagina).on('click', function () {
    var totalPaginas = Number($(totalRegistros).text()) / Number($(selectorPagina).val());
    totalPaginas = Math.trunc(totalPaginas) + 1;
    if(totalPaginas === 1){
       return;
       }
    cambiarPagina(totalPaginas, $(selectorPagina).val());
    
  });
  //-----------------------------------------------------------------------------------------------
  
  //Ordenar por columnas-------------------------------------------------------
  $(idSort).on('click', function () {
    ordenar('idPago');
  });
  $(localizadorSort).on('click', function () {
    ordenar('pago.idLocalizador');
    
  });
  $(nombreSort).on('click', function () {
    ordenar('tasa.descTasa');
  });
  $(importeSort).on('click', function () {
    ordenar('importe');
  });
  $(nrcSort).on('click', function () {
    ordenar('nrc');
  });
  $(fhSort).on('click', function () {
    ordenar('fhPago');
  });
  $(estadoSort).on('click', function () {
    ordenar('estado');
  });
  $(pagadorSort).on('click', function () {
    ordenar('pago.pagador.nombrePagador');
  });
  $(razonSocialSort).on('click', function () {
    ordenar('pago.pagador.razonSocialPagador');
  });
  //-----------------------------------------------------------------------------------------------
  
  //Descargar excel con o sin filtros-------------------------------------------------------
  $(btnExportExcelCies).on('click', function () {
    descargarExcelFiltros();
  });
  $(btnExportExcel).on('click', function () {
    descargarExcelFiltros();
  });
  //-----------------------------------------------------------------------------------------------

  //Botón de volver--------------------------------------------------------------------------------
  $(btnVolver).on('click', function () {
    if ($(volver).val() != null && Number($(volver).val()) < 0) {
      window.history.go(Number($(volver).val()));
    } else {
      window.location.href='/pagojus-frontconsola/adminPagos/consolaPrincipal';
    }
  });
  //-----------------------------------------------------------------------------------------------

  //Desplegable de fecha---------------------------------------------------------------------------
  $('.entradaFechaBajo input').datepicker({
    format: "dd/mm/yyyy",
    clearBtn: true,
    orientation: "bottom left",
    language: "es",
    autoclose: true
  });
  //-----------------------------------------------------------------------------------------------

  //Cambiar valor actual del selector de pagina ---------------------------------------------------
  var url = new URL(window.location.href);
  if(url.searchParams.get('tamPag') != null){
    $(selectorPagina).val(url.searchParams.get('tamPag'));
  }
  //-----------------------------------------------------------------------------------------------

  // Habilitar/Deshabilitar boton de editar cambios detalle--------------------------------------------------------------
  // Se comprueba primero si hay que habilitar/deshabilitar el campo de NRC
  toggleNrcTasaCorregido();
  
  $(nrcTasaCorregido).on('change', toggleBotonEditar);
  $(expedienteCorregido).on('change', toggleBotonEditar);
  $(estadoTasaCorregido).on('change', function() {
    toggleBotonEditar();
    toggleNrcTasaCorregido();
  });
  
  function toggleBotonEditar() {
    const nrcTasaCorregidoVal = $(nrcTasaCorregido).val().trim();
    const expedienteCorregidoVal = $(expedienteCorregido).val().trim();
    const estadoTasaCorregidoVal = $(estadoTasaCorregido).val().trim();
  
    if (
      (nrcTasaCorregidoVal !== '' && nrcTasaCorregidoVal !== $(nrcTasa).val()) ||
      (expedienteCorregidoVal !== '' && expedienteCorregidoVal !== $(expediente).val()) ||
      (estadoTasaCorregidoVal !== '' && estadoTasaCorregidoVal !== $(estadoTasa).val())
    ) {
      $(btnEditar).prop('disabled', false).removeClass('btnEditarDisabled');
    } else {
      $(btnEditar).prop('disabled', true).addClass('btnEditarDisabled');
    }
  }

  // Deshabilitar campos de edición de NRC si el estado de la tasa no permite su edidicion
  // Al estar o pasar a estados diferentes de PAGADO, el campo NRC se deshabilita
  function toggleNrcTasaCorregido() {
    const rol = $(codAplicacion).val();

    if(rol != 'VENTANILLA') {
      const estadoTasaCorregidoVal = $(estadoTasaCorregido).val().trim();
  
      let estadoTasaFinal = $(estadoTasa).val().trim();
      if (estadoTasaCorregidoVal != '') {
        estadoTasaFinal = estadoTasaCorregidoVal;
      }
  
      if(estadoTasaFinal === 'PAGADO') {
          $(nrcTasaCorregido).prop('disabled', false)
      }
      else {
        $(nrcTasaCorregido).val('');
        $(nrcTasaCorregido).prop('disabled', true)  
      }
    }
  }
  //-----------------------------------------------------------------------------------------------

  // Deshabilitar campos de edición si el rol es VENTANILLA, o si el estado de la tasa no permite su edidicion
  if($(codAplicacion).val() === 'VENTANILLA' 
  || $(estadoTasa).val() === 'INICIADO' 
  || $(estadoTasa).val() === 'NO_PAGADO' 
  || $(estadoTasa).val() === 'DEVUELTO') {
    $(nrcTasaCorregido).prop('readonly', 'enabled');
    $(expedienteCorregido).prop('readonly', 'enabled');
  }
  //-----------------------------------------------------------------------------------------------

  // Deshabilitar seleccionable de estado si no hay suficientes opciones en el desplegable---------
  $(estadoTasaCorregido).ready(function () {
    const optionCount = $(estadoTasaCorregido).children('option').length;
    if (optionCount === 1) {
      $(estadoTasaCorregido).prop('disabled', true);
    }
  });
  //-----------------------------------------------------------------------------------------------

  //Ancla a la tabla tras busqueda-----------------------------------------------------------------
  var url = window.location.href;
  if(url.includes("Busqueda")){
    window.location.hash="resultado";
  }
   // Volver al login desde noRole.error-----------------------------------------------------------
   
   $('#noRoleOut').on('click', function() {
     noRoleLogOut();
    
  });
  
  
  //-----------------------------------------------------------------------------------------------
});


function noRoleLogOut(){
  document.getElementById('noRoleOutForm').submit();
}
function cambiarPagina(pagina, tamano) {
  muestraCargando();
  var url = new URL(window.location.href);
  url.searchParams.set('numPag', pagina);
  url.searchParams.set('tamPag', tamano);

  window.location.href = url.href;

  return true;
}

function ordenar(valor) {
    muestraCargando(); // Muestra el spinner
    var url = new URL(window.location.href);
    var params = url.searchParams;

    var orderParam = params.get('orderBy');
    var ascParam = params.get('asc');

    if (orderParam === valor && ascParam === 'true') {
        params.set('asc', 'false'); // Cambiar a orden descendente
        let elemento = document.querySelector(mapValorToConstant(valor));
        if (elemento) {
            //elemento.classList.add('desc');
            let arrow = elemento.querySelector('.arrow');
            if (arrow) {  arrow.textContent = DESC_ARROW; } // Flecha descendente
        }
    } else {
        params.set('asc', 'true'); // Cambiar a orden ascendente
        let elemento = document.querySelector(mapValorToConstant(valor));
        if (elemento) {
            //elemento.classList.add('asc');
            let arrow = elemento.querySelector('.arrow');
            if (arrow) { arrow.textContent = ASC_ARROW; } // Flecha ascendente
        }
    }

    params.set('orderBy', valor);

    url.search = params.toString();
   
    // Redirigir
    window.location.href = url.href;

    return true;
}
function mapValorToConstant(valor) {
    const mapping = {
        'idPago': '#idSort',
        'pago.idLocalizador': '#localizadorSort',
        'tasa.descTasa': '#nombreSort',
        'importe': '#importeSort',
        'nrc': '#nrcSort',
        'fhPago': '#fhSort',
        'estado': '#estadoSort',
        'pago.pagador.nombrePagador': '#pagadorSort',
        'pago.pagador.razonSocialPagador': '#razonSocialSort'
    };
    return mapping[valor] || valor;
}

document.addEventListener('DOMContentLoaded', (event) => {
    var url = new URL(window.location.href);
    var orderParam = mapValorToConstant(url.searchParams.get('orderBy'));
    var ascParam = url.searchParams.get('asc');

    // Si orderParam es válido, encontrar la cabecera correspondiente
    if (orderParam) {
        var cabecera = document.querySelector(orderParam);
        if (cabecera) {
            if (ascParam === 'true') {
                //cabecera.classList.add('asc');
                let arrow = cabecera.querySelector('.arrow');
                if (arrow) { arrow.textContent = ASC_ARROW; } // Flecha ascendente
            } else {
                //cabecera.classList.add('desc');
                let arrow = cabecera.querySelector('.arrow');
                if (arrow) { arrow.textContent = DESC_ARROW; } // Flecha descendente
            }
        }
    }
});


function descargarExcelFiltros() {
  muestraCargando();
  var url = window.location.href;
  if(url.includes("Busqueda") && $(totalRegistros).text() != "0"){
      var lastIndex = url.lastIndexOf("?");
    if(lastIndex==-1){
      window.location.href = url + "/excel"
    } else {
      var prefix = url.slice(0, lastIndex);
      var sufix = url.slice(lastIndex);
      window.location.href = prefix + "/excel" + sufix;
    }
  }
  $body = $("body");
  $("body").removeClass("loading");
  return;
}
