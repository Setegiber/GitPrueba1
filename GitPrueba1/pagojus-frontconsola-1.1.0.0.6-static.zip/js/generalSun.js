/*kleinder nuevo*/
$(document).ready(function(){
	$('.L_terciaria').on('click', function(){
		if($(this).find('.icon-Seach').hasClass('fa-angle-up')){
			$(this).find('.icon-Seach').removeClass('fa-angle-up');
			$(this).find('.icon-Seach').addClass('fa-angle-down');
		}else if($(this).find('.icon-Seach').hasClass('fa-angle-down')){
			$(this).find('.icon-Seach').addClass('fa-angle-up');
			$(this).find('.icon-Seach').removeClass('fa-angle-down');
		}
	});

	$(".question-i").hover(function(){
			$( this ).parent().find('.question-i-div').css('display','block');
	    }, function(){
	    	$( this ).parent().find('.question-i-div').css('display','none');
	});

	if($("#filtroComunidadAutonoma").val() != null && $("#filtroComunidadAutonoma").val() !== '') {
		cargarProvincias();
	}
	if($("#provinciaHidden").val() != null && $("#provinciaHidden").val() !== '') {
		cargarMunicipios();
	}
	
	$("#filtroComunidadAutonoma").on("change", function() {
		$('#provinciaHidden').val("");
		$('#municipioHidden').val("");
		$("#filtroProvincia").empty();
		$("#filtroMunicipio").empty();
		$('#filtroProvincia').append('<option value="" selected>NO SELECCIONADO</option>');
		$('#filtroMunicipio').append('<option value="" selected>NO SELECCIONADO</option>');
		
		if($("#filtroComunidadAutonoma").val() !== null && $("#filtroComunidadAutonoma").val() !== ''){
			cargarProvincias();
		}
	})
	
	$("#filtroProvincia").on("change", function() {
		$("#filtroMunicipio").empty();
		$('#municipioHidden').val("");
		$('#filtroMunicipio').append('<option value="" selected>NO SELECCIONADO</option>');
		$('#provinciaHidden').val($("#filtroProvincia").val());
		if($("#filtroProvincia").val() !== null && $("#filtroProvincia").val() !== '') {
			cargarMunicipios();
		}
		
	})
	
	$("#filtroMunicipio").on("change", function() {
		$('#municipioHidden').val($("#filtroMunicipio").val());
	})

});

async function mostrarImagen(url) {
    let ventana;
    if (navigator.windowControlsOverlay && window.getScreenDetails) {
        ventana = window.open(url, 'Imagen', `width=${screen.width},height=${screen.height}`);
        try {
            const screenDetails = await window.getScreenDetails();
            const primaryScreen = screenDetails.screens.find(screen => screen.isPrimary);
            const secondaryScreen = screenDetails.screens.find(screen => !screen.isPrimary);

            if (secondaryScreen) {
                ventana = window.open(url, 'Imagen', `width=${secondaryScreen.width},height=${secondaryScreen.height}`);
                ventana.moveTo(secondaryScreen.left, secondaryScreen.top);
            } else {
                const screenWidth = screen.width;
                const screenHeight = screen.height;

                if (primaryScreen.width < screenWidth || primaryScreen.height < screenHeight) {
                    ventana = window.open(url, 'Imagen', `width=${screenWidth},height=${screenHeight},zoom=150%`);
                    ventana.moveTo(0, 0);
                } else {
                    ventana = window.open(url, 'Imagen', `width=${screen.width},height=${screen.height}`);
                }
            }
            ventana.onload = function() {
		        const body = ventana.document.body;
		        body.style.transform = 'scale(2)';
		        body.style.transformOrigin = '0 0';
		        body.style.width = `${100 / 2}%`;
		    };
        } catch (error) {
            console.error('Error al obtener detalles de la pantalla:', error);
            ventana = window.open(url, 'Imagen', `width=${screen.width},height=${screen.height}`);
        }
    } else {
        console.warn('API de ventanas no soportada en este navegador.');
        ventana = window.open(url, 'Imagen', `width=${screen.width},height=${screen.height}`);
    }
}


let cargarProvincias = function() {
	$.ajax({
		type: 'POST',
		url: 'getProvinciasPorComunidadBusquedaUDC',
		data: {
	            codComunidadAutonoma: $("#filtroComunidadAutonoma").val()
	        },
		success: function(result) {
			let provincias = $.parseJSON(result);
			if (provincias !== null && provincias.length > 0) {
				$.each(provincias, function(index, value) {
					$("#filtroProvincia").append($("<option />").val(value.codProvincia).text(value.provincia));
				});
				if(provincias.length < 2){
					$('#filtroProvincia').prop('selectedIndex', 1).change();
				}
				if($('#provinciaHidden').val() != null && $('#provinciaHidden').val() !== '') {
					$('#filtroProvincia').val($('#provinciaHidden').val());
				}
			}
			
			
		},
		error: function(result) {
			alert('Ha ocurrido un error');
		}
	});
};

let cargarMunicipios = function() {
	$.ajax({
		type: 'POST',
		url: 'getMunicipiosPorProvinciaBusquedaUDC',
		data: {
	            codProvincia: $("#provinciaHidden").val()
	        },
		success: function(result) {
			let municipios = $.parseJSON(result);
			if (municipios !== null && municipios.length > 0) {
				$.each(municipios, function(index, value) {
					$("#filtroMunicipio").append($("<option />").val(value.codMunicipio).text(value.municipio));
				});
				if(municipios.length < 2){
					$('#filtroMunicipio').prop('selectedIndex', 1).change();
				}
				if($('#municipioHidden').val() != null && $('#municipioHidden').val() !== '') {
					$('#filtroMunicipio').val($('#municipioHidden').val());
				}
			}
			
			
		},
		error: function(result) {
			alert('Ha ocurrido un error');
		}
	});
}
/*Aqui*/
function muestraCargando() {
	$body = $("body");
	$("body").addClass("loading");
	almacenaScroll();
	return true;
}

function clearForm(myFormElement) {

  var formulario = document.forms[0];
	
  var elements = formulario.elements;
  
  for(let i=0; i<elements.length; i++) {

  var field_type = elements[i].type.toLowerCase();

  switch(field_type) {

    case "text":
    case "password":
    case "textarea":
          case "hidden":

      elements[i].value = "";
      break;

    case "radio":
    case "checkbox":
        if (elements[i].checked) {
          elements[i].checked = false;
      }
      break;

    case "select-one":
    case "select-multi":
                elements[i].selectedIndex = -1;
      break;

    default:
      break;
  }
    }
}

function ayuda(pantalla){
	window.open(pantalla,"_blank",'toolbar=0,location=0,menubar=0,resizable=yes, width=500, height=300');
}

function almacenaScroll() {
	if ($('.valorScroll')) {
		$('.valorScroll').val($(document).scrollTop());
	}
}

function checkValue(id) {
	var checkbox = document.getElementById(id);
	  if (checkbox.checked == true)
	  {
		  checkbox.value = true;
	  }
	  if (checkbox.checked == false)
	  {
		  checkbox.value = false;
	  }
}

function checkError(id) {
	var checkError = document.getElementById(id);
	if (checkError != null && checkError.value != null) {
		$("#buttonModal").trigger("click");
	}
}



function saltoScroll() {
	if ($('.valorScroll') && $('.valorScroll').val() != null) {
		$(document).scrollTop($('.valorScroll').val());
	}
}

function seleccionaConsentimiento(btn) {
	var id = $('#destinatarioEscogido').val();
	if ($('#consentimiento' + btn).is(':checked')) {
		$('#aceptar' + btn).attr('disabled', false);
		if(btn == "Acepto") {
			$('#aceptar' + btn).attr('href', "reintentarRegistro.htm?id=" + id);
		} else {
			$('#aceptar' + btn).attr('href', "cancelarRegistro.htm?id=" + id);
		}
			
	} else {
		$('#aceptar' + btn).attr('disabled', true);
		$('#aceptar' + btn).attr('href', "javascript:;");
	}
}

function mostrarPassword(check) {
	if ($('#' + check).is(':checked')) {
		$('#pass').attr('type', 'text');
	}else{
		$('#pass').attr('type', 'password');
	}
}

function cargarIdDestinatario(accion, id) {
	$('#' + accion).val(id);
}

function cargarIdDestinatarioPantalla(accion, id, pantalla) {
	$('#' + accion).val(id + pantalla);
}

function restaurarCheck(accion) {
	$('#' + accion).removeAttr('checked')
}

function cambiarValorCheck(check, hidd) {
	if ($('#' + check).is(':checked')) {
		$('#' + hidd).val(true);
	} else {
		$('#' + hidd).val(false);
	}
}

$.fn.pageMe = function(opts){
    var $this = this,
        defaults = {
            perPage: 7,
            showPrevNext: false,
            hidePageNumbers: false
        },
        settings = $.extend(defaults, opts);
    
    var listElement = $this;
    var perPage = settings.perPage; 
    var children = listElement.children();
    var pager = $(settings.pagerclass);
    
    if (typeof settings.childSelector!="undefined") {
        children = listElement.find(settings.childSelector);
    }
    
    if (typeof settings.pagerSelector!="undefined") {
        pager = $(settings.pagerSelector);
    }
    
    var numItems = children.size();
    var numPages = Math.ceil(numItems/perPage);
	    if (numPages > 1) {
		pager.data("curr", 0);

		if (settings.showPrevNext) {
			$('<li><a href="#" class="prev_link">«</a></li>').appendTo(pager);
		}

		var curr = 0;
		while (numPages > curr && (settings.hidePageNumbers == false)) {
			$('<li><a href="#" class="page_link">' + (curr + 1) + '</a></li>')
					.appendTo(pager);
			curr++;
		}

		if (settings.showPrevNext) {
			$('<li><a href="#" class="next_link">»</a></li>').appendTo(pager);
		}

		pager.find('.page_link:first').addClass('active');
		pager.find('.prev_link').hide();
		if (numPages <= 1) {
			pager.find('.next_link').hide();
		}
		pager.children().eq(0).addClass("active");

		children.hide();
		children.slice(0, perPage).show();

		pager.find('li .page_link').click(function() {
			var clickedPage = $(this).html().valueOf() - 1;
			goTo(clickedPage, perPage);
			return false;
		});
		pager.find('li .prev_link').click(function() {
			previous();
			return false;
		});
		pager.find('li .next_link').click(function() {
			next();
			return false;
		});
	}
    
    function previous(){
        var goToPage = parseInt(pager.data("curr")) - 1;
        goTo(goToPage);
    }
     
    function next(){
        var goToPage = parseInt(pager.data("curr")) + 1;
        goTo(goToPage);
    }
    
    function goTo(page){
        var startAt = page * perPage,
            endOn = startAt + perPage;
        
        children.css('display','none').slice(startAt, endOn).show();
        
        if (page>=1) {
            pager.find('.prev_link').show();
        }
        else {
            pager.find('.prev_link').hide();
        }
        
        if (page<(numPages-1)) {
            pager.find('.next_link').show();
        }
        else {
            pager.find('.next_link').hide();
        }
        
        pager.data("curr",page);
      	pager.children().removeClass("active");
        pager.children().eq(page).addClass("active");
    
    }

}