function obtenerParametro(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

window.onload = function() {
    const sesionCaducada = obtenerParametro('sesionCaducada');
    if (sesionCaducada === '1') {
        const mensaje = document.getElementById('mensaje-sesion-caducada');
        mensaje.style.display = 'flex';
    }

    // Muestra de mensaje en pagina de login si ha habido error -------------------------------------
    var url = window.location.href;
    if(url.includes("error")){
        var usrPassError = document.getElementById("usrPassError");
        usrPassError.classList.remove("d-none");
    }
    //-----------------------------------------------------------------------------------------------

};