let valoresOriginales = {};
window.onload = desactivarGuardadoInicial;
$(document).ready(function() {
	if($('#camposLimiteHidden').val() != '') {
		let camposCorregidos = {
			"PAGINA-FOLIO" : $('#idPaginaCorregido').val(),
			"BIS" : $('#idBisCorregido').val(),
			"VUELTA": $('#idVueltaCorregido').val(),
			"TIPO" : $('#idTipoInscripcionCorregido').val(),
			"NOMBRE" : $('#idNombreCorregido').val(),
			"PRIMER_APELLIDO" : $('#idApellido1Corregido').val(),
			"SEGUNDO_APELLIDO" : $('#idApellido2Corregido').val(),
			"FEC_NACIMIENTO/FECHA" : $('#idFechaNacCorregido').val(),
			"FEC_DEFUNCION/FECHA" : $('#FechaDefCorregido').val()
			};
		
		let camposOrigen = {
			"PAGINA-FOLIO" : $('#idPagina').val(),
			"BIS" : $('#idBis').val(),
			"VUELTA": $('#idVuelta').val(),
			"TIPO" : $('#idTipoInscripcion').val(),
			"NOMBRE" : $('#idNombre').val(),
			"PRIMER_APELLIDO" : $('#idApellido1').val(),
			"SEGUNDO_APELLIDO" : $('#idApellido2').val(),
			"FEC_NACIMIENTO/FECHA" : $('#idFechaNac').val(),
			"FEC_DEFUNCION/FECHA" : $('#FechaDef').val()
			};
		let mapaCampos = {
			    'PAGINA-FOLIO': 'Pagina',
			    'BIS': 'Bis',
			    'VUELTA': 'Vuelta',
			    'TIPO': 'TipoInscripcion',
			    'NOMBRE': 'Nombre',
			    'PRIMER_APELLIDO': 'Apellido1',
			    'SEGUNDO_APELLIDO': 'Apellido2',
			    'FEC_NACIMIENTO/FECHA': 'FechaNac',
			    "FEC_DEFUNCION/FECHA" : 'FechaDef'
			};
		setConfirmacionGuardado(mapaCampos, camposOrigen, camposCorregidos);
	}
	
	
});

function setConfirmacionGuardado(mapaCampos, camposOrigen, camposCorregidos) {
    
    var camposLimiteHidden = $('#camposLimiteHidden').val();
    var camposLimiteLista = camposLimiteHidden.replace(/[\[\]]/g, '').split(',').map(campo => campo.trim()).filter(campo => campo !== ''); 
    
    camposLimiteLista.forEach(function(palabraClave) {
		
		let idCampo = "#id"+mapaCampos[palabraClave]+"Corregido";
   		$(idCampo).on('blur', function() {
            detectarCambios(mapaCampos, camposLimiteLista, camposOrigen, camposCorregidos);
        });
    });
    
}

function detectarCambios(mapaCampos, listaPalabras, camposOrigen, camposCorregidos) {
    
    let cambiosDetectados = false;
   	for (let i = 0; i < listaPalabras.length; i++) {
        
        let palabraClave = listaPalabras[i];
        
        let campoOrigen = camposOrigen[palabraClave];
        let campoCorregido = camposCorregidos[palabraClave];
        let valorCampoActual = $("#id"+mapaCampos[palabraClave]+"Corregido").val();
        
        if (valorCampoActual !== campoOrigen && valorCampoActual !== campoCorregido) {
            cambiosDetectados = true;
        }
	}
	if(cambiosDetectados) {
		$("#btnGuardarSinAviso").addClass("d-none");
		$("#btnGuardarConAviso").removeClass("d-none");
	} else {
		$("#btnGuardarConAviso").addClass("d-none");
		$("#btnGuardarSinAviso").removeClass("d-none");
	}
}

function toggleConfirmarRechazo(event) {
	event.preventDefault();
	$('#modalConfirmarRechazoInsc').modal({
    		backdrop: 'static',
    		keyboard: false
    	}).css({'padding-right':'10%'});
}

function confirmarRechazo(event) {
	event.preventDefault();
	$('#btnRechazo').click();
}

function cancelarRechazo(event) {
	event.preventDefault();
	$('#modalConfirmarRechazoInsc').modal('toggle');
	return false;
}

function toggleConfirmarGuardado(event) {
	event.preventDefault();
	$('#modalConfirmarGuardado').modal({
    		backdrop: 'static',
    		keyboard: false
    	}).css({'padding-right':'10%'});
}

function confirmarGuardado(event) {
	event.preventDefault();
	$('#btnGuardado').click();
}

function cancelarGuardado(event) {
	event.preventDefault();
	$('#modalConfirmarGuardado').modal('toggle');
	return false;
}


// Función que compara el valor de dos campos y cambia el color de fondo si son iguales
function compararYResaltar(campoOriginal, campoCorregido) {
	// Obtener los elementos por sus IDs
	const campo1 = $('#' + campoOriginal).val();
	const campo2 = $('#' + campoCorregido).val();

	// Comparar los valores de los campos
	if (campo1 === campo2) {
		// Cambiar el color de fondo a amarillo si son iguales
		$('#' + campoCorregido).css("background-color", "white");        
    } else {		
        // Restablecer el color de fondo si no son iguales
        $('#' + campoCorregido).css("background-color", "lightyellow");
	}

}

function activarGuardado() {
	const ids = ['Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 'Nombre', 'Apellido1', 'Apellido2', 'FechaNac', 'FechaDef', 
	'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'];

	// Metodo para simplificar implementación de IDs
	ids.forEach(id => {
//		const valorOriginal = $(`#id${id}`).val();
//		$('#' + 'wwgrp_' + `id${id}Corregido`).show();
		valoresOriginales[id] = $(`#id${id}Corregido`).val();
		$(`#id${id}Corregido`).attr('disabled', false);
		compararYResaltar(`id${id}`, `id${id}Corregido`);
	});

//	$("div.entradaFechaBajo > input#idFechaNacCorregido").parent().show();
//	$("div.entradaFechaBajo > input#idFechaDefCorregido").parent().show();

	$('#divBotonAcciones').addClass("d-none");
	$('#divBotonGuardar').removeClass("d-none");

	return false;
}

function desactivarGuardado() {
	const ids = ['Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 'Nombre', 'Apellido1', 'Apellido2', 'FechaNac', 'FechaDef', 
	'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'];

	// Metodo para simplificar implementación de IDs
	ids.forEach(id => {
//		const valorOriginal = $(`#id${id}`).val();
//		$('#' + 'wwgrp_' + `id${id}Corregido`).hide();
		$(`#id${id}Corregido`).val(valoresOriginales[id]);
		$(`#id${id}Corregido`).attr('disabled', true);
		compararYResaltarDesactivado(`id${id}`, `id${id}Corregido`);
	});

//	$("div.entradaFechaBajo > input#idFechaNacCorregido").parent().hide();
//	$("div.entradaFechaBajo > input#idFechaDefCorregido").parent().hide();

	$('#divBotonAcciones').removeClass("d-none");
	$('#divBotonGuardar').addClass("d-none");

	return false;
}

function compararYResaltarDesactivado(campoOriginal, campoCorregido) {
	// Obtener los elementos por sus IDs
    const campo1 = $('#' + campoOriginal).val();
    const campo2 = $('#' + campoCorregido).val();

    // Comparar los valores de los campos
    if (campo1 === campo2) {		
        // Cambiar el color de fondo a amarillo si son iguales
        $('#' + campoCorregido).css("background-color", "whitesmoke");        
    } else {		
        // Restablecer el color de fondo si no son iguales
        $('#' + campoCorregido).css("background-color", "lightyellow");
    }
}

function desactivarGuardadoInicial() {
	const ids = ['Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 'Nombre', 'Apellido1', 'Apellido2', 'FechaNac', 'FechaDef', 
	'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'];

    ids.forEach(id => {

		$(`#id${id}Corregido`).attr('disabled', true);
		compararYResaltarDesactivado(`id${id}`, `id${id}Corregido`);
		
		// Obtener el elemento correspondiente a la ID
		const elementCorregido = document.getElementById(`id${id}Corregido`);
		
		// Verificar si el elemento no es un checkbox antes de agregar el listener
		if (elementCorregido.type !== 'checkbox') {

			// Forzar mayusculas
			document.getElementById(`id${id}`).addEventListener('input', function() {
				this.value = this.value.toUpperCase()
			});

			document.getElementById(`id${id}Corregido`).addEventListener('input', function() {
				this.value = this.value.toUpperCase()
			});

		}
    });
    
	$('#divBotonAcciones').removeClass("d-none");
	$('#divBotonGuardar').addClass("d-none");
	
	comprobarChecks();
	
	return false;
}

function comprobarChecks() {
	const dDefVOCorregidoErrNoCorresponde = document.getElementById('idImagenNoCorrespondeHidden');
	const dDefVOCorregidoErrFaltaDatos = document.getElementById('idImagenFaltaDatosHidden');
	const dDefVOCorregidoErrLugarIncorrecto = document.getElementById('idImagenLugarIncorrectoHidden')
	
	const checkboxNoCorresponde = document.getElementById('idImagenNoCorrespondeCorregido');
	const checkboxFaltaDatos = document.getElementById('idImagenFaltaDatosCorregido');
	const checkboxLugarIncorrecto = document.getElementById('idImagenLugarIncorrectoCorregido')
	
	if (dDefVOCorregidoErrNoCorresponde.value === 'true') {
	  checkboxNoCorresponde.checked = true;
	}
	
	if (dDefVOCorregidoErrFaltaDatos.value === 'true') {
	  checkboxFaltaDatos.checked = true;
	}
	
	if (dDefVOCorregidoErrLugarIncorrecto.value === 'true') {
	  checkboxLugarIncorrecto.checked = true;
	}

}