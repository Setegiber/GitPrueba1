package zen.playwright;

public class Zen extends ZenJenkins {
}
