package zen.playwright;

import corium.playwright.CoriumPlaywrightExtends;

public class ZenPaths extends CoriumPlaywrightExtends {

}
