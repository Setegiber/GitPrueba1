package zen.playwright;

public class ZenMethods extends ZenProperties {

    private int countRequestTry = 3;
    private Integer countSteps = 0;
    private Integer countPreconditionSteps = 0;

    /**
     * Adds a step to the test execution with a given message.
     *
     * @param message The message describing the step.
     */
    public void pasos(String message) {
        countSteps++;
        infoLabelMessageCategoryType("Paso " + countSteps.toString() + " - " + message);
        loggerSlf4jInfo("Paso " + countSteps.toString() + " - " + message);
    }

    /**
     * Adds a precondition step to the test execution with a given message.
     *
     * @param message The message describing the precondition step.
     */
    public void precondiciones(String message) {
        countPreconditionSteps++;
        infoLabelMessageCategoryType("Precondicion " + countPreconditionSteps.toString() + " - " + message);
        loggerSlf4jInfo("Precondicion " + countPreconditionSteps.toString() + " - " + message);
    }
}
