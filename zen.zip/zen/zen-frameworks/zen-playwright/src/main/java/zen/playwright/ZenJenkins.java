package zen.playwright;

public class ZenJenkins extends ZenMethods {
}
