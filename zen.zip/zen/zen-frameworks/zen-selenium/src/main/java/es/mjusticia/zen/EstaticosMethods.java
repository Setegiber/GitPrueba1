package es.mjusticia.zen;

import es.mjusticia.corium.ApiMethods;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EstaticosMethods extends Estaticos {

	public static JusticiaProperties justiciaProperties = new JusticiaProperties();
	public static ApiMethods apiMethods = new ApiMethods();
	public static JusticiaPaths projectsPath = new JusticiaPaths();

	public String staticPath = "static/";
	public String theme1StaticPath = "theme1/";

	/**
	 * Processes the specified directory path and sends HTTP GET requests for each file found,
	 * using the provided URI path.
	 *
	 * @param directoryFilesPath The path to the directory containing the files to process.
	 * @param uriPath            The URI path to append to the base URI for each file request.
	 * @throws IOException          If an I/O error occurs.
	 * @throws InterruptedException If the thread is interrupted while waiting.
	 */
	public void getRequestEstaticosEverything(String directoryFilesPath, String uriPath) throws IOException, InterruptedException {
		splitPathDirectory(directoryFilesPath, uriPath);
	}

	/**
	 * Recursively walks through the specified main directory path, identifies regular files,
	 * and sends HTTP GET requests for each file found, using the provided URI path.
	 *
	 * @param mainDirectoryPath The path to the main directory to walk through.
	 * @param uriPath           The URI path to append to the base URI for each file request.
	 */
	public void splitPathDirectory(String mainDirectoryPath, String uriPath){
		try (Stream<Path> walk = Files.walk(Paths.get(new File(mainDirectoryPath).getAbsolutePath()))) {
			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());
			for (int i = 0; i < result.size(); i++){
				String replaceSlashes = result.get(i).split("estaticos_desarrollo")[1]
						.replace("\\","/")
						.substring(1)
						.replaceAll(" ", "%20");
				apiMethods.httpRequest(
						apiMethods.defaultClientHttp2Configuration(),
						uriPath + replaceSlashes,
						"get",
						null,
						null,
						(String) null);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
