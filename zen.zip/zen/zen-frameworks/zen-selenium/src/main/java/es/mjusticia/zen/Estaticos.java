package es.mjusticia.zen;

import es.mjusticia.corium.FrameworkMethods;

public class Estaticos extends FrameworkMethods {

    public static final String
            ESTATICOSNAME = "estaticos/estaticos_desarrollo/";

}
