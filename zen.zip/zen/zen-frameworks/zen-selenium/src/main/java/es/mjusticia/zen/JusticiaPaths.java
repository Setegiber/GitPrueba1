package es.mjusticia.zen;

public class JusticiaPaths extends JusticiaProperties {

    public static final String
            JUSTICIAPATH = "src/main/java/justicia/";

    public static final String
            PROJECTSPATH = JUSTICIAPATH + "projects/";

}
