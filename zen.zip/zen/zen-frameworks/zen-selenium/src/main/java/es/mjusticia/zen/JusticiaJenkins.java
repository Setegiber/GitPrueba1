package es.mjusticia.zen;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.mjusticia.corium.utils.FrameworkJenkins;

/**
 * The {@code JusticiaJenkins} class provides utilities and methods specifically designed for integration with Jenkins,
 * a popular open-source automation server widely used for continuous integration and continuous delivery (CI/CD) pipelines.
 * This class encapsulates Jenkins-related functionality tailored for Justicia projects.
 *
 * @author Paul Raad
 */

public class JusticiaJenkins extends JusticiaPaths {

    private static String
            jobNameProcesosSh = "Calidad-EjecutarProcesosSH",
            jobNameModificacionDatos = "Calidad-ModificacionDatosAplicaciones";

    private static FrameworkJenkins frameworkJenkins = new FrameworkJenkins();

    /**
     * Executes a Jenkins job for processing shell scripts, providing input parameters
     * such as project name, deployment form name, script name, and job time validation duration.
     *
     * @param proyectoName                   The name of the project.
     * @param fichaDespliegueName            The name of the deployment form.
     * @param scriptName                     The name of the shell script.
     * @param jobTimeValidationDurationSeconds The duration (in seconds) for job time validation.
     * @throws IOException                  If an I/O error occurs.
     * @throws InterruptedException         If the thread is interrupted while waiting.
     */
    public void ejecutarProcesosSh(String proyectoName,String fichaDespliegueName, String scriptName, int jobTimeValidationDurationSeconds) throws IOException, InterruptedException {
        loggerSlf4jInfo("Se va a ejecutar el job: " + jobNameProcesosSh);
        frameworkJenkins.executeJobJenkinsFullInput(frameworkJenkins.getJenkinsUsernameProperty(),
                frameworkJenkins.getJenkinsPasswordProperty(),
                frameworkJenkins.getJenkinsHostProperty(),
                jobNameProcesosSh,jobTimeValidationDurationSeconds,
                Map.of( "Proyecto", proyectoName,
                        "FichaDespliegue",fichaDespliegueName,
                        "Scripts",scriptName));
        loggerSlf4jInfo("Job finalizado con exito");
    }

    /**
     * Executes a Jenkins job for modifying application data, providing input parameters
     * such as deployment form name, file name, and job time validation duration.
     *
     * @param fichaDespliegueName            The name of the deployment form.
     * @param nombreFicheroName              The name of the file.
     * @param jobTimeValidationDurationSeconds The duration (in seconds) for job time validation.
     */
    public void modificacionDatosAplicaciones(String fichaDespliegueName, String nombreFicheroName, int jobTimeValidationDurationSeconds) {
        loggerSlf4jInfo("Se va a ejecutar el job: " + jobNameModificacionDatos);
        frameworkJenkins.executeJobJenkinsFullInput(frameworkJenkins.getJenkinsUsernameProperty(),
                frameworkJenkins.getJenkinsPasswordProperty(),
                frameworkJenkins.getJenkinsHostProperty(),
                jobNameModificacionDatos,jobTimeValidationDurationSeconds,
                Map.of("FichaDespliegue", fichaDespliegueName,
                        "NombreFichero",nombreFicheroName));
        loggerSlf4jInfo("Se va a ejecutar el job: " + jobNameModificacionDatos);
    }

    //***********************************Procesos jenkins

    //ejecutar scripts de BD
    public String ejecutarSH(String comando) {
        String resultado="";
        try {
            Process p = Runtime.getRuntime().exec(comando);
            p.waitFor();
            BufferedReader buf = new BufferedReader(new InputStreamReader(
                    p.getInputStream()));
            String line = "";
            String output = "";
            while ((line = buf.readLine()) != null) {
                line=line.trim();
                if(!line.equals("")) {
                    output += line + "\n";
                }
            }
            if(output.contains("\n")) {
                output=output.substring(0,output.length()-1);
            }
            resultado=output;
        } catch (Exception e) {
            resultado="ERROR ejecutarSH comando:"+comando+"\n"+e;
            System.out.println(resultado);
        }
        return resultado;
    }

    //metodo para ejecutarScriptBDLocal
    public List ejecutarScriptsBD(String sql,  String jdbc, String usuario,String pass) {
        ResultSet rset=null;
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
        Map<String, Object> row = null;
        try {
            Connection conn = null;
            conn = DriverManager.getConnection(jdbc, usuario, pass);
            Statement stmt = conn.createStatement();
            rset = stmt.executeQuery(sql);
            ResultSetMetaData metaData = rset.getMetaData();
            Integer columnCount = metaData.getColumnCount();
            while (rset.next()) {
                row = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(metaData.getColumnName(i), rset.getObject(i));
                }
                resultList.add(row);
            }
            stmt.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return resultList;
    }
}
