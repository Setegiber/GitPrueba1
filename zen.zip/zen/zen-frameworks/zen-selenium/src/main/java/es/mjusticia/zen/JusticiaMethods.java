package es.mjusticia.zen;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.InvalidCookieDomainException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;

import okhttp3.Response;


/**
 * The {@code JusticiaMethods} class provides utilities and methods specifically designed for handling various tasks
 * related to the Justicia projects. These methods encapsulate project-specific functionality
 * and are intended to streamline development and maintenance efforts for the project.
 *
 * @author Paul Raad
 */

public class JusticiaMethods extends JusticiaJenkins {

    private int countRequestTry = 3;
    private Integer countSteps = 0;
    private Integer countPreconditionSteps = 0;

    private static final String sePasarelaClave = "https://se-pasarela.clave.gob.es/Proxy2/ServiceProvider";

    WebDriver claveWebdriver = null;
    private Set<Cookie> claveCookies = null;

    /**
     * Cleans up the Clave WebDriver environment after the test class execution.
     * Invokes the {@code tearDown(WebDriver)} method with the Clave WebDriver instance.
     */
    @AfterClass(alwaysRun = true)
    public void tearDownConfigClave() {
        tearDown(claveWebdriver);
    }

    /**
     * Simulates key events to interact with Autofirma certificate popup.
     * Pauses for 10 seconds, presses Tab twice, then Enter twice.
     */
    public void robotFirmarAutofirmaCertificado() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            pause(15);
            robotKeyEvent(KeyEvent.VK_TAB);
            robotKeyEvent(KeyEvent.VK_TAB);
            robotKeyEvent(KeyEvent.VK_ENTER);
            pause(15);
            robotKeyEvent(KeyEvent.VK_ENTER);
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            if (getSeleniumBrowserDriverProperty().contains("edge")) {
                pause(15);
                robotKeyEvent(KeyEvent.VK_TAB);
                robotKeyEvent(KeyEvent.VK_ENTER);
                pause(15);
                robotKeyEvent(KeyEvent.VK_ENTER);
            } else {
                pause(15);
                robotKeyEvent(KeyEvent.VK_ENTER);
            }
        } else {
            exitAndFailProgram("This operating system is not supported for AutoFirma: " + os);
        }
    }

    /**
     * Logs into Clave using Firefox profile with default profile name "eidas".
     *
     * @param urlFinalRedirectionClave The URL to navigate for logging in.
     */
    public void loginClaveFirefoxProfile(String urlFinalRedirectionClave) {
        loginClaveFirefoxProfile(urlFinalRedirectionClave,urlFinalRedirectionClave);
    }

    public void loginClaveFirefoxProfile(String urlHost, String urlFinalRedirectionClave) {
        loginClaveFirefoxProfile(urlHost, urlFinalRedirectionClave, "eidas");
    }


    /**
     * Logs into Clave using Firefox profile with the given profile name.
     * Deletes existing cookies, sets up Firefox profile, navigates to the URL, performs login steps, and manages cookies.
     *
     * @param urlHost                The URL to navigate for logging in.
     * @param profileFirefoxName The name of the Firefox profile to use.
     */

    public void loginClaveFirefoxProfile(String urlHost, String urlFinalRedirectionClave, String profileFirefoxName) {
        loginClaveFirefoxProfile(urlHost,urlFinalRedirectionClave,profileFirefoxName,urlFinalRedirectionClave, null, 0);
    }

    public void loginClaveFirefoxProfile(String urlHost, String urlFinalRedirectionClave, String profileFirefoxName, String differentUrlFinalRedirectionClave) {
        loginClaveFirefoxProfile(urlHost,urlFinalRedirectionClave,profileFirefoxName,differentUrlFinalRedirectionClave, null, 0);
    }

    public void loginClaveFirefoxProfile(String urlHost, String urlFinalRedirectionClave, String profileFirefoxName, String differentUrlFinalRedirectionClave, By elementToBeClickedBeforeClave) {
        loginClaveFirefoxProfile(urlHost,urlFinalRedirectionClave,profileFirefoxName,differentUrlFinalRedirectionClave, elementToBeClickedBeforeClave, 0);
    }

    public void loginClaveFirefoxProfile(String urlHost, String urlFinalRedirectionClave, String profileFirefoxName, String differentUrlFinalRedirectionClave, By elementToBeClickedBeforeClave, int elementToBeClickedBeforeClaveIndex) {
        loginClaveFirefoxProfileGeneral(urlFinalRedirectionClave,profileFirefoxName,differentUrlFinalRedirectionClave, elementToBeClickedBeforeClave, elementToBeClickedBeforeClaveIndex);
        loginClaveFirefoxProfileHandleCookies(urlFinalRedirectionClave);
    }

    private void loginClaveFirefoxProfileGeneral(String urlFinalRedirectionClave ,String profileFirefoxName, String pasarelaClaveValidation, By elementToBeClickedBeforeClave, int elementToBeClickedBeforeClaveIndex){
        String urlFinalRedirectionClaveModified = urlFinalRedirectionClave;
        if (pasarelaClaveValidation != urlFinalRedirectionClaveModified){
            urlFinalRedirectionClaveModified = pasarelaClaveValidation;
            loggerSlf4jInfo("Different final redirection Clave, new value = " + urlFinalRedirectionClaveModified);
        }
        try{
            if (getSeleniumBrowserDriverProperty().toLowerCase().startsWith("firefox")){
                claveWebdriver = null;
                tearDown(webDriver);
                webDriver = null;
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                webDriver = claveWebdriver;
                getUrl(urlFinalRedirectionClave);
                if (elementToBeClickedBeforeClave != null){
                    clickElement(findElements(elementToBeClickedBeforeClave).get(elementToBeClickedBeforeClaveIndex));
                }
                waitUntilUrlContains(sePasarelaClave);
                pause(3);
                loginClaveFirefoxProfileLoopUrlVerification(byCssSelector("button[class='idp-button']"),sePasarelaClave,1,webDriver);
                waitUntilUrlContains(urlFinalRedirectionClaveModified, 120);
            }else {
                claveWebdriver = null;
                deleteCookiesWebdriver();
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                getUrl(urlFinalRedirectionClave, claveWebdriver);
                if (elementToBeClickedBeforeClave != null){
                    clickElement(findElements(elementToBeClickedBeforeClave,claveWebdriver).get(elementToBeClickedBeforeClaveIndex));
                }
                waitUntilUrlContains(sePasarelaClave, claveWebdriver);
                pause(3);
                loginClaveFirefoxProfileLoopUrlVerification(byCssSelector("button[class='idp-button']"),sePasarelaClave,1);
                waitUntilUrlContains(urlFinalRedirectionClaveModified, 120,claveWebdriver);
            }
        }catch (Exception e) {
            claveWebdriver.quit();
            throw e;
        }
    }

    public void loginCertificateFirefoxProfile(String urlRedirectionClave, String urlFinalRedirectionCertificate ,String profileFirefoxName, By elementToBeClickedBeforeCertificate){
        loginCertificateFirefoxProfileGeneral(urlRedirectionClave,urlFinalRedirectionCertificate,profileFirefoxName,elementToBeClickedBeforeCertificate);
        loginClaveFirefoxProfileHandleCookies(urlFinalRedirectionCertificate);
        getUrl(urlFinalRedirectionCertificate);
    }

    private void loginCertificateFirefoxProfileGeneral(String urlRedirectionCertificate, String urlFinalRedirectionCertificate ,String profileFirefoxName, By elementToBeClickedBeforeCertificate){
        try{
            if (getSeleniumBrowserDriverProperty().toLowerCase().startsWith("firefox")){
                claveWebdriver = null;
                tearDown(webDriver);
                webDriver = null;
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                webDriver = claveWebdriver;
                getUrl(urlRedirectionCertificate);
                pause(3);
                loginClaveFirefoxProfileLoopUrlVerification(elementToBeClickedBeforeCertificate,sePasarelaClave,0,webDriver);
                waitUntilUrlContains(urlFinalRedirectionCertificate, IMPLICIT_WAIT);
            }else {
                claveWebdriver = null;
                deleteCookiesWebdriver();
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                getUrl(urlRedirectionCertificate, claveWebdriver);
                pause(3);
                loginClaveFirefoxProfileLoopUrlVerification(elementToBeClickedBeforeCertificate,urlFinalRedirectionCertificate,0,claveWebdriver);
                waitUntilUrlContains(urlFinalRedirectionCertificate, IMPLICIT_WAIT,claveWebdriver);
            }
        }catch (Exception e) {
            claveWebdriver.quit();
            throw e;
        }
    }

    public void loginCertificateUrlFirefoxProfile(String urlRedirectionClave,By waitForByElementToBeDisplayedAfterCertificate){
        loginCertificateUrlFirefoxProfile(urlRedirectionClave,urlRedirectionClave,"eidas", waitForByElementToBeDisplayedAfterCertificate,0);
    }

    public void loginCertificateUrlFirefoxProfile(String urlRedirectionClave,String urlFinalRedirectionCertificate, By waitForByElementToBeDisplayedAfterCertificate){
        loginCertificateUrlFirefoxProfile(urlRedirectionClave,urlFinalRedirectionCertificate,"eidas", waitForByElementToBeDisplayedAfterCertificate,0);
    }

    public void loginCertificateUrlFirefoxProfile(String urlRedirectionClave,String urlFinalRedirectionCertificate, String profileFirefoxName, By waitForByElementToBeDisplayedAfterCertificate, int waitForByElementToBeDisplayedAfterCertificateIndex){
        loginCertificateUrlFirefoxProfileGeneral(urlRedirectionClave,urlFinalRedirectionCertificate,profileFirefoxName, waitForByElementToBeDisplayedAfterCertificate, waitForByElementToBeDisplayedAfterCertificateIndex);
        loginClaveFirefoxProfileHandleCookies(urlFinalRedirectionCertificate);
    }

    private void loginCertificateUrlFirefoxProfileGeneral(String urlRedirectionCertificate,String urlFinalRedirectionCertificate,String profileFirefoxName, By waitForByElementToBeDisplayedAfterCertificate,int waitForByElementToBeDisplayedAfterCertificateIndex){
        try{
            if (getSeleniumBrowserDriverProperty().toLowerCase().startsWith("firefox")){
                claveWebdriver = null;
                tearDown(webDriver);
                webDriver = null;
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                webDriver = claveWebdriver;
                getUrl(urlRedirectionCertificate);
                waitUntilUrlContains(urlFinalRedirectionCertificate, IMPLICIT_WAIT);
                waitUntilElementIsDisplayed(findElements(waitForByElementToBeDisplayedAfterCertificate).get(waitForByElementToBeDisplayedAfterCertificateIndex));
            }else {
                claveWebdriver = null;
                getUrl("https://www.mjusticia.gob.es/es/ciudadania/tramites");
                deleteCookiesWebdriver();
                claveWebdriver = firefoxSetupProfile(profileFirefoxName, claveWebdriver);
                getUrl(urlRedirectionCertificate, claveWebdriver);
                waitUntilUrlContains(urlFinalRedirectionCertificate, IMPLICIT_WAIT,claveWebdriver);
                waitUntilElementIsDisplayed(findElements(waitForByElementToBeDisplayedAfterCertificate,claveWebdriver).get(waitForByElementToBeDisplayedAfterCertificateIndex));
                pause(5);
            }
        }catch (Exception e) {
            claveWebdriver.quit();
            throw e;
        }
    }

    private void loginClaveFirefoxProfileLoopUrlVerification(By cssSelectorToClick, String urlInLoop, int elementsNumber){
        loginClaveFirefoxProfileLoopUrlVerification(cssSelectorToClick,urlInLoop,elementsNumber,claveWebdriver);
    }

    private void loginClaveFirefoxProfileLoopUrlVerification(By cssSelectorToClick, String urlInLoop, int elementsNumber, WebDriver claveWebdriverLoop){
        turnOnImplicitWaitsNoChange(5);
        try {
            clickElement(findElements(cssSelectorToClick, claveWebdriverLoop).get(elementsNumber));
        } catch (Exception e) {
            loggerSlf4jInfo(e.getMessage());
        }
        turnOnImplicitWaitsNoChange(1);
        if (getCurrentUrl(claveWebdriverLoop) == urlInLoop) {
            for (int i = 0; i <= 30; i++) {
                try {
                    clickElement(findElements(cssSelectorToClick, claveWebdriverLoop).get(elementsNumber));
                    pause(3);
                    if (getCurrentUrl(claveWebdriverLoop) != urlInLoop) {
                        break;
                    }
                } catch (Exception e) {
                    loggerSlf4jInfo(e.getMessage());
                }
            }
        }
        turnOnImplicitWaits();
    }

    private void loginClaveFirefoxProfileHandleCookies(String urlClave){
        if (getSeleniumBrowserDriverProperty().toLowerCase().startsWith("firefox")){
            return;
        }
        waitUntilUrlContains(urlClave, 120, claveWebdriver);
        claveCookies = getCookiesWebdriver(claveWebdriver);
        for (Cookie seleniumCookie : claveCookies) {
            try {
                addCookiesWebdriver(claveCookies, webDriver);
            } catch (InvalidCookieDomainException e) {
                loggerSlf4jInfo("Invalid cookie domain: " + e.getMessage());
            } catch (Exception e) {
                loggerSlf4jInfo("Error adding cookie: " + seleniumCookie.getName() + " - " + e.getMessage());
            }
        }
        claveWebdriver.quit();
        getUrl(urlClave);
    }

    /**
     * Sends a SOAP HTTP POST request with default cookies and checks if the response body contains a specified content.
     *
     * @param requestUri       The URI of the SOAP service.
     * @param xmlInput         The XML input for the SOAP request.
     * @param soapAction       The SOAP action header value.
     * @param contentTypeValue The content type header value.
     * @param pageContains     The content to check for in the response body.
     * @return The HTTP response if the response body contains the specified content.
     */
    public HttpResponse httpSoapRequestDefaultCookiesBodyContains(String requestUri, String xmlInput, String soapAction, String contentTypeValue, String pageContains) {
        return httpSoapRequestDefaultCookiesBodyContains(requestUri, xmlInput, soapAction, contentTypeValue, pageContains, 3);
    }

    /**
     * Sends a SOAP HTTP POST request with default cookies and checks if the response body contains a specified content,
     * allowing for a specified number of retries.
     *
     * @param requestUri       The URI of the SOAP service.
     * @param xmlInput         The XML input for the SOAP request.
     * @param soapAction       The SOAP action header value.
     * @param contentTypeValue The content type header value.
     * @param pageContains     The content to check for in the response body.
     * @param numberOfTries    The number of times to attempt the request.
     * @return The HTTP response if the response body contains the specified content.
     */
    public HttpResponse httpSoapRequestDefaultCookiesBodyContains(String requestUri, String xmlInput, String soapAction, String contentTypeValue, String pageContains, int numberOfTries) {
        countRequestTry = numberOfTries;
        for (int i = 0; i < countRequestTry; i++) {
            HttpResponse response = httpRequest(
                    defaultClientHttp2Configuration(),
                    requestUri,
                    "post",
                    Map.of("SOAPAction", soapAction,
                            "Content-Type", contentTypeValue),
                    null,
                    xmlInput);
            if (response.body().toString().contains(pageContains)) {
                return response;
            }
            pause(5);
        }
        exitAndFailProgram("soapRequest was not able to find a message containing: " + pageContains);
        return null;
    }

    /**
     * Asserts the successful access to the "Consulta de certificado de antecedentes penales" page.
     * <p>
     * This method checks if the page title contains the expected text indicating successful access.
     * </p>
     * <p>
     * If the assertion fails, the program exits and prints an error message indicating the failure reason.
     * </p>
     */
    public void assertAccesoAntecedentes() {
        try {
            Assert.assertTrue(webId("consulta_antecedentes_penales").findElement(By.className("titulo")).getText().contains("Consulta de certificado de antecedentes penales"));
        } catch (AssertionError e) {
            exitAndFailProgram(e.getMessage() + " - " +
                    webId("mensaje").findElement(By.className("actionMessage")).getText());
        }
    }

    /**
     * Returns the name of the properties file for the MJusticia framework.
     *
     * @return The name of the properties file.
     */
    public String mjusticiaFrameworkPropertiesName() {
        return "mjusticiaframework.properties";
    }

    /**
     * Returns the property name for the valid Clave certificate in the certificates properties file.
     *
     * @return The property name for the valid Clave certificate.
     */
    public String certificatesClaveValidCertificatePropertyName() {
        return "certificates.clave.valid.certificate";
    }

    /**
     * Returns the property name for the password of the valid Clave certificate in the certificates properties file.
     *
     * @return The property name for the password of the valid Clave certificate.
     */
    public String certificatesClaveValidCertificatePasswordPropertyName() {
        return "certificates.clave.valid.certificate.password";
    }

    /**
     * Returns the class representing the location of Clave certificate resources.
     *
     * @return The class representing the location of Clave certificate resources.
     */
    public Class getClaveClassCertificatesResourcesLocation() {
        return JusticiaMethods.class;
    }

    /**
     * Returns the path to the JAR file containing the valid Clave certificate.
     *
     * @return The path to the JAR file containing the valid Clave certificate.
     */
    public String getClaveValidCertificateJarPath() {
        return getJavaPropertyValue(getClaveClassCertificatesResourcesLocation(), mjusticiaFrameworkPropertiesName(), certificatesClaveValidCertificatePropertyName());
    }

    /**
     * Returns the password for the valid Clave certificate.
     *
     * @return The password for the valid Clave certificate.
     */
    public String getClaveValidCertificateJarPassword() {
        return getJavaPropertyValue(getClaveClassCertificatesResourcesLocation(), mjusticiaFrameworkPropertiesName(), certificatesClaveValidCertificatePasswordPropertyName());
    }

    /**
     * Executes a command specified by a command string in the operating system command prompt.
     *
     * @param commandCmd The command string to execute.
     */
    public void autoFirmaSignDocumentFullCmdCommand(String commandCmd) {
        Process process = null;
        try {
            String[] commandArgs = commandCmd.split(" ");

            ProcessBuilder processBuilder = new ProcessBuilder(commandArgs);
            process = processBuilder.start();
            boolean finished = process.waitFor(60, TimeUnit.SECONDS);
            if (!finished) {
                System.err.println("Command failed with timeout" );
                process.destroyForcibly();
                throw new IllegalStateException("Timeout ejecutando el comando");
            }
            int exitCode = process.exitValue();
            if (exitCode == 0) {
                System.out.println("Command executed successfully.");
            } else {
                System.err.println("Command failed with exit code: " + exitCode);
                throw new IllegalStateException("Error ejecutando comando. Exit code: " + exitCode);
            }

        } catch (IOException | IllegalStateException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        } finally {
            if (process != null) {
                process.destroy();
            }
        }

    }

    /**
     * Signs a document using AutoFirma, a command-line based tool, with specified parameters.
     *
     * @param inputFile        The input stream of the document to sign.
     * @param outputFileName   The name of the signed document file.
     * @param format           The format of the signature.
     * @param algorithm        The algorithm used for signing.
     * @param store            The input stream of the keystore containing the signing certificate.
     * @param storeType        The type of the keystore (e.g., "pkcs12").
     * @param storePassword    The password for the keystore.
     * @param storeAlias       The alias of the signing certificate in the keystore (optional).
     * @param additionalParams Additional parameters for the signing process (optional).
     * @return The signed document file.
     */
    public File autoFirmaSignDocument(InputStream inputFile, String outputFileName, String format, String algorithm,
                                      InputStream store, String storeType, String storePassword, String storeAlias, Map<String, String> additionalParams) {
        File tempDir = null;
        File inputFileTemp = null;
        String inputFilePath = null;
        File storeFileTemp = null;
        String storePath = null;
        Process process = null;
        try {
            tempDir = Files.createTempDirectory("autoFirmaTemp").toFile();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        try {
            if (inputFile != null) {
                String fileExtension = outputFileName.substring(outputFileName.lastIndexOf('.'));
                inputFileTemp = new File(tempDir, "inputFile" + fileExtension);
                inputFilePath = inputFileTemp.getAbsolutePath();
                Files.copy(inputFile, inputFileTemp.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } else {
                loggerSlf4jInfo("Error creating inputFile, inputFile is null");
                return null;
            }

            if (store != null) {
                String storeExtension = storeType.equals("pkcs12") ? ".p12" : ".other"; // Adjust as needed
                storeFileTemp = new File(tempDir, "storeFile" + storeExtension);
                storePath = storeFileTemp.getAbsolutePath();
                Files.copy(store, storeFileTemp.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } else {
                loggerSlf4jInfo("Error creating store, store is null");
                return null;
            }

            List<String> commandArgs = new ArrayList<>();
            commandArgs.add("AutoFirmaCommandLine.exe");
            commandArgs.add("sign");
            appendParameter(commandArgs, "-i", inputFilePath);
            appendParameter(commandArgs, "-format", format);
            appendParameter(commandArgs, "-algorithm", algorithm);
            appendParameter(commandArgs, "-store", storeType + ":" + storePath);
            appendParameter(commandArgs, "-password", storePassword);
            if (storeAlias != null) {
                appendParameter(commandArgs, "-alias", storeAlias);
            }
            appendParameter(commandArgs, "-o", new File(DOWNLOADS_PATH).getAbsolutePath() + "\\" + outputFileName);

            File file = new File(DOWNLOADS_PATH + "\\" + outputFileName);

            if (additionalParams != null) {
                for (Map.Entry<String, String> entry : additionalParams.entrySet()) {
                    appendParameter(commandArgs, entry.getKey(), entry.getValue());
                }
            }

            String[] commandArray = commandArgs.toArray(new String[0]);

            ProcessBuilder processBuilder = new ProcessBuilder(commandArray);

            process = processBuilder.start();
            boolean finished = process.waitFor(60, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                throw new IllegalStateException("Timeout ejecutando el comando");
            }
            int exitCode = process.exitValue();
            if (exitCode != 0) {
                throw new IllegalStateException("Error ejecutando comando. Exit code: " + exitCode);
            }

            inputFileTemp.delete();
            storeFileTemp.delete();
            tempDir.delete();

            return file;
        } catch (IOException | IllegalStateException e) {
            e.printStackTrace();
            loggerSlf4jError(e.getMessage());
            inputFileTemp.delete();
            storeFileTemp.delete();
            tempDir.delete();
            return null;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
            loggerSlf4jError(e.getMessage());
            inputFileTemp.delete();
            storeFileTemp.delete();
            tempDir.delete();
            return null;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }

    private static void appendParameter(List<String> commandArgs, String parameter, String value) {
        if (value != null && !value.isEmpty()) {
            commandArgs.add(parameter);
            commandArgs.add(value);
        }
    }

    private void skipCurrentTestInfo(String currentEnvironment) {
        info("<environment.execution> property = " + currentEnvironment);
        info("Current test will be skipped, test requires preconditions");
        info("Current method in the moment of skip: " + getMethodName(4));
        throw new SkipException("Skipping test...");
    }

    @Deprecated
    public void skipCurrentTestEnvironment() {
        if (getLoggerEnvironmentExecutionProperty().equalsIgnoreCase("int")) {
            skipCurrentTestInfo("int");
        }
        if (getLoggerEnvironmentExecutionProperty().equalsIgnoreCase("pre")) {
            skipCurrentTestInfo("pre");
        }
    }

    /**
     * Adds a step to the test execution with a given message.
     *
     * @param message The message describing the step.
     */
    public void pasos(String message) {
        countSteps++;
        infoLabelMessageCategoryType("Paso " + countSteps.toString() + " - " + message);
        logger.info("Paso " + countSteps.toString() + " - " + message);
    }

    /**
     * Adds a precondition step to the test execution with a given message.
     *
     * @param message The message describing the precondition step.
     */
    public void precondiciones(String message) {
        countPreconditionSteps++;
        infoLabelMessageCategoryType("Precondicion " + countPreconditionSteps.toString() + " - " + message);
        logger.info("Precondicion " + countPreconditionSteps.toString() + " - " + message);
    }

    /**
     * Sends a POST request using OkHttp with custom headers and parameters, and returns the response body as a string.
     *
     * @param uri              The URI of the resource to send the request to.
     * @param restrictedHeader The value of the 'Referer' header to include in the request.
     * @param postKeyValues    A map containing the key-value pairs of the parameters to send in the request body.
     * @return The response body as a string if the request is successful, or null if an IO error occurs.
     */
    public String postOkHttpHeaders(String uri, String restrictedHeader, Map<String, String> postKeyValues) {
        try {
            Response response = okRequest(
                    defaultClientOk2Configuration(),
                    uri,
                    "post",
                    Map.of("Referer", restrictedHeader),
                    null,
                    postKeyValues,
                    MEDIA_TYPE_X_WWW_FORM_URLENCODED());
            return response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Generates a random NIE (Número de Identificación de Extranjero) with a valid prefix.
     *
     * @return A randomly generated valid NIE.
     */
    public static String generateNie() {
        String generatedNIE;
        boolean valid;
        do {
            String NIE_LETTERS = "XYZ";
            Random random = new Random();
            char niePrefix = NIE_LETTERS.charAt(random.nextInt(NIE_LETTERS.length()));
            int randomNumberPart = random.nextInt(10000000 - 1000) + 1000;
            char nieFinalLetter = getDniLetter(randomNumberPart);
            generatedNIE = niePrefix + String.format("%07d", randomNumberPart) + nieFinalLetter;
            valid = validNIE(generatedNIE);
        } while (!valid);
        loggerSlf4jInfo("Valid NIE generated: " + generatedNIE);
        return generatedNIE;
    }

    private static char getDniLetter(int dni) {
        String dniLetters = "TRWAGMYFPDXBNJZSQVHLCKE";
        int letterIndex = dni % 23;
        return dniLetters.charAt(letterIndex);
    }

    private static boolean validNIE(String nie) {
        char niePrefix = nie.charAt(0);
        int niePrefixValue;
        switch (niePrefix) {
            case 'X':
                niePrefixValue = 0;
                break;
            case 'Y':
                niePrefixValue = 1;
                break;
            case 'Z':
                niePrefixValue = 2;
                break;
            default:
                return false;
        }
        return validDNI(niePrefixValue + nie.substring(1));
    }

    private static boolean validDNI(String dni) {
        String dniLetters = "TRWAGMYFPDXBNJZSQVHLCKE";
        int letterIndex = Integer.parseInt(dni.substring(0, 8)) % 23;
        char calculatedLetter = dniLetters.charAt(letterIndex);
        return calculatedLetter == dni.charAt(8);
    }
}
