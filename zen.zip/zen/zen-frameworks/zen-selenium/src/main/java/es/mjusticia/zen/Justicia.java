package es.mjusticia.zen;

public class Justicia extends JusticiaMethods {
}
