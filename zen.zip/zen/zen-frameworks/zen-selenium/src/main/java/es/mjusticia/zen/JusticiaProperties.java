package es.mjusticia.zen;


import es.mjusticia.corium.FrameworkExtended;

/**
 * The {@code JusticiaProperties} class provides utilities and methods specifically designed for managing properties
 * related to the Justicia projects. These methods encapsulate project-specific configuration
 * and are intended to facilitate the management and retrieval of Justicia properties.
 *
 * @author Paul Raad
 */

public class JusticiaProperties extends FrameworkExtended {

    public String getHostNameProperty = "";
    public static String LOGO_MINISTERIO = "https://www.mjusticia.gob.es/Siteassets/images/logos/logo-ministerio-mpjrc.svg";

    {
        setSeleniumBrowserDriverProperty("firefox");
    }

    /**
     * Configures Extent Reports with custom scripts to enhance the report appearance.
     *
     * @param projectName The name of the project to be displayed in the Extent Reports.
     */
    public void extentReportsMjusticiaScripts(String projectName){
        spark.config().setJs("var img = document.createElement('img');\n" +
                "img.src = '" + LOGO_MINISTERIO + "';\n" +
                "img.style.position = 'absolute';\n" +
                "img.style.left = '20%';\n" +
                "img.style.top = '3px';\n" +
                "img.style.height = '90%';\n" +
                "img.style.maxWidth = '15%';\n" +
                "var holder = document.getElementsByClassName('vheader')[0];\n" +
                "holder.appendChild(img); \n" +
                "var robotText = document.createElement('div');\n" +
                "robotText.textContent = '"+ projectName +"';\n" +
                "robotText.style.fontFamily = 'Arial, sans-serif';\n" +
                "robotText.style.fontSize = '20px';\n" +
                "robotText.style.fontWeight = 'bold';\n" +
                "robotText.style.color = '#ddd';\n" +
                "robotText.style.position = 'absolute';\n" +
                "robotText.style.left = '50%';\n" +
                "robotText.style.top = '50%';\n" +
                "robotText.style.transform = 'translate(-50%, -50%)';\n" +
                "robotText.style.textAlign = 'center';\n" +
                "holder.appendChild(robotText);");
    }
}
