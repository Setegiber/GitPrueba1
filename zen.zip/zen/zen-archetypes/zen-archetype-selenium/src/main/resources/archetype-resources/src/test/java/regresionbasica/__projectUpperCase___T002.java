package ${package}.regresionbasica;

import org.testng.annotations.Test;
import ${package}.homepage.Homepage;

/**
 *  @author Your Name Here
 *  @version Java 17.0.2
 *
 *  <h1>${projectIdJavaClass} Smoke Test</h1>
 *  <h2>Refer to: <a href="https://jira.mjusticia.es/secure/Tests.jspa#/testCase/${projectUpperCase}">${projectUpperCase}-T001</a></h2>
 *
 *  <h3> Test created: 01/07/2022 </h3>
 *  <h3> Test finished: 04/07/2022 </h3>
 *  <h3> Test update: 23/10/2024 </h3>
 *  <h3> Test update by: Your Name Here </h3>
 *  <h3> Test JIRA current version: 2.0 </h3>
 *
 **/

public class ${projectUpperCase}_T002 extends Homepage {

    @Test (description = "Your test description here")
    public void ${projectUpperCase}_T002_Test() {
        pasos("El usuario navega a ${projectUpperCase}");
        getUrl(${projectUpperCase}_URL);
    }
}
