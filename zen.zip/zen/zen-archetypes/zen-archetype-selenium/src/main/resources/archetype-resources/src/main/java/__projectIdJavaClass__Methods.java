package ${package};

public class ${projectIdJavaClass}Methods extends ${projectIdJavaClass} {

}
