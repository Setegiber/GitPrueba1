package ${package};

import es.mjusticia.zen.JusticiaMethods;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class ${projectIdJavaClass}Properties extends JusticiaMethods {

    private static String getJavaPropertyValueProject(String propertyName){
        return getJavaPropertyValue(${projectIdJavaClass}Properties.class,
                "${projectLowerCase}.properties",
                propertyName);
    }

    public static final String
    ${projectUpperCase}_URL = getJavaPropertyValueProject("${projectLowerCase}.url");

    @BeforeClass
    public void extentReportsMjusticiaScriptsProject(){
        extentReportsMjusticiaScripts("${projectUpperCase}");
    }

    @BeforeMethod
    public void ${projectLowerCase}Category(){
        test.assignCategory("${projectUpperCase}");
    }
}
