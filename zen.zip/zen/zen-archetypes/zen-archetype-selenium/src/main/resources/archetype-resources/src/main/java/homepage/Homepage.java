package ${package}.homepage;

import ${package}.${projectIdJavaClass};

public class Homepage extends ${projectIdJavaClass} {

}
