package ${package};

public class ${projectIdJavaClass} extends ${projectIdJavaClass}Properties {

}
