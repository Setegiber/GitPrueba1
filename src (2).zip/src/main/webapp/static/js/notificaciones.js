var idAnt = '';
function mostrarError(fecha, codigo, desc, idDat, idDest) {
	if (idAnt == idDat) {
		$('#errorFoot' + idDest).slideToggle(400, function() {
			if ($('#errorFoot' + idDest).is(':visible')) {
//				window.location.hash = '#errorFoot' + idDest;
			}
		});
	} else {
		if (!$('#errorFoot' + idDest).is(':visible')) {
			$('#errorFoot' + idDest).slideToggle(400, function() {
				if ($('#errorFoot' + idDest).is(':visible')) {
//					window.location.hash = '#errorFoot' + idDest;
				}
			});
		}
	}
	var str = fecha + " --> " + "COD: " + codigo + ": " + desc;
	$('#error' + idDest).text(str);
	idAnt = idDat;
}