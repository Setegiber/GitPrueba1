document.addEventListener('DOMContentLoaded', function() {
    // Selecciona el tbody que contiene las filas
    const udcTableBody = document.getElementById('udcTableBody');

    // Añade un event listener al tbody para delegar eventos
    udcTableBody.addEventListener('click', function(event) {
        // Verifica si el elemento clicado es un botón de tipo submit
        if (event.target.closest('button[type="submit"]')) {
            // Encuentra la fila (tr) más cercana al botón clicado
            const row = event.target.closest('tr');
            if (row) {
                // Obtiene el valor de data-nombre-udc de la fila
                const nombreUDC = row.getAttribute('data-nombre-udc');
                // Asigna el valor al campo oculto idUdc
                document.querySelector('input[name="idUdc"]').value = nombreUDC;
            }
        }
    });
});