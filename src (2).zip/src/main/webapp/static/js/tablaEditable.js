/**
 * 
 */

var miTabla = 'tabla-ordenable'; // poner aquí el id de la tabla que queremos editar
var valorCeldaOld;
// preparar la tabla para edición
function iniciarTabla() {
 	tab = document.getElementById(miTabla);
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
  	celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i==0 || j==celdas.length-1 || j==0) continue; // La última columna  y la última fila no se pueden editar
      cel.onclick = function() {crearInput(this)} 
    } // end for j 
  } //end for i
}

//crear input para editar datos
function crearInput(celda) {
  celda.onclick = function() {return false}
  txt = celda.innerHTML;
  valorCeldaOld = txt;
  celda.innerHTML = '';
  obj = celda.appendChild(document.createElement('input'));
  obj.value = txt;
  obj.focus();
  
  obj.onblur = function() {
    txt = this.value;
    celda.removeChild(obj);
    celda.innerHTML = txt;
    celda.onclick = function() {crearInput(celda)}
//    sumar();
    id = celda.id.split("_");
    if("descripcion" == id[0]){
    	descripcion=txt;
    	precio=document.getElementById("precio_"+id[1]).innerHTML;
    }else{
    	descripcion=document.getElementById("descripcion_"+id[1]).innerHTML;
    	precio=txt;    
    }
    
    window.location="/prototipo/producto/actualizar.htm?id="+id[1]+"&descripcion= "+descripcion+"&precio="+precio;
  }
  
  
}