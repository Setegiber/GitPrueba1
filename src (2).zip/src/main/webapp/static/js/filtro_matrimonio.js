let valoresOriginales = {};

window.onload = desactivarGuardadoInicial;
$(document).ready(function() {
	if($('#camposLimiteHidden').val() != '') {
		let camposCorregidos = {
			'PAGINA-FOLIO' : $('#idPaginaCorregido').val(),
			'BIS' : $('#idBisCorregido').val(),
			'VUELTA': $('#idVueltaCorregido').val(),
			'TIPO' : $('#idTipoInscripcionCorregido').val(),
			'CONYUGE1/NOMBRE' : $('#idNombre1Corregido').val(),
			'CONYUGE1/PRIMER_APELLIDO' : $('#idApellido11Corregido').val(),
			'CONYUGE1/SEGUNDO_APELLIDO' : $('#idApellido21Corregido').val(),
			'CONYUGE1/FEC_NACIMIENTO/FECHA' : $('#idFecha1Corregido').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/POBLACION' : $('#idMunicipio1Corregido').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/PROVINCIA' : $('#idProvincia1Corregido').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/PAIS' : $('#idPais1Corregido').val(),
			'CONYUGE2/NOMBRE' : $('#idNombre2Corregido').val(),
			'CONYUGE2/PRIMER_APELLIDO' : $('#idApellido12Corregido').val(),
			'CONYUGE2/SEGUNDO_APELLIDO' : $('#idApellido22Corregido').val(),
			'CONYUGE2/FEC_NACIMIENTO/FECHA' : $('#idFecha2Corregido').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/POBLACION' : $('#idMunicipio2Corregido').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/PROVINCIA' : $('#idProvincia2Corregido').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/PAIS' : $('#idPais2Corregido').val(),
			'FEC_MATRIMONIO/FECHA' : $('#idFechaMatrimonioCorregido').val()
			};
		
		let camposOrigen = {
			'PAGINA-FOLIO' : $('#idPagina').val(),
			'BIS' : $('#idBis').val(),
			'VUELTA': $('#idVuelta').val(),
			'TIPO' : $('#idTipoInscripcion').val(),
			'CONYUGE1/NOMBRE' : $('#idNombre1').val(),
			'CONYUGE1/PRIMER_APELLIDO' : $('#idApellido11').val(),
			'CONYUGE1/SEGUNDO_APELLIDO' : $('#idApellido21').val(),
			'CONYUGE1/FEC_NACIMIENTO/FECHA' : $('#idFecha1').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/POBLACION' : $('#idMunicipio1').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/PROVINCIA' : $('#idProvincia1').val(),
			'CONYUGE1/LUGAR_NACIMIENTO/PAIS' : $('#idPais1').val(),
			'CONYUGE2/NOMBRE' : $('#idNombre2').val(),
			'CONYUGE2/PRIMER_APELLIDO' : $('#idApellido12').val(),
			'CONYUGE2/SEGUNDO_APELLIDO' : $('#idApellido22').val(),
			'CONYUGE2/FEC_NACIMIENTO/FECHA' : $('#idFecha2').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/POBLACION' : $('#idMunicipio2').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/PROVINCIA' : $('#idProvincia2').val(),
			'CONYUGE2/LUGAR_NACIMIENTO/PAIS' : $('#idPais2').val(),
			'FEC_MATRIMONIO/FECHA' : $('#idFechaMatrimonio').val()
			};
		let mapaCampos = {
		    'PAGINA-FOLIO': 'Pagina',
		    'BIS': 'Bis',
		    'VUELTA': 'Vuelta',
		    'TIPO': 'TipoInscripcion',
		    'CONYUGE1/NOMBRE': 'Nombre1',
		    'CONYUGE1/PRIMER_APELLIDO': 'Apellido11',
		    'CONYUGE1/SEGUNDO_APELLIDO': 'Apellido21',
		    'CONYUGE1/FEC_NACIMIENTO/FECHA': 'Fecha1',
		    'CONYUGE1/LUGAR_NACIMIENTO/PAIS' : 'Pais1',
		    'CONYUGE1/LUGAR_NACIMIENTO/PROVINCIA' : 'Provincia1',
		    'CONYUGE1/LUGAR_NACIMIENTO/POBLACION' : 'Municipio1',
		    'CONYUGE2/NOMBRE': 'Nombre2',
		    'CONYUGE2/PRIMER_APELLIDO': 'Apellido12',
		    'CONYUGE2/SEGUNDO_APELLIDO': 'Apellido22',
		    'CONYUGE2/FEC_NACIMIENTO/FECHA': 'Fecha2',
		    'CONYUGE2/LUGAR_NACIMIENTO/PAIS' : 'Pais2',
		    'CONYUGE2/LUGAR_NACIMIENTO/PROVINCIA' : 'Provincia2',
		    'CONYUGE2/LUGAR_NACIMIENTO/POBLACION' : 'Municipio2',
		    'FEC_MATRIMONIO/FECHA' : 'FechaMatrimonio'
			};
		setConfirmacionGuardado(mapaCampos, camposOrigen, camposCorregidos);
	}
});

function setConfirmacionGuardado(mapaCampos, camposOrigen, camposCorregidos) {
    
    var camposLimiteHidden = $('#camposLimiteHidden').val();
    var camposLimiteLista = camposLimiteHidden.replace(/[\[\]]/g, '').split(',').map(campo => campo.trim()).filter(campo => campo !== ''); 
    
    camposLimiteLista.forEach(function(palabraClave) {
		
		let idCampo = "#id"+mapaCampos[palabraClave]+"Corregido";
   		$(idCampo).on('blur', function() {
            detectarCambios(mapaCampos, camposLimiteLista, camposOrigen, camposCorregidos);
        });
    });
    
}

function detectarCambios(mapaCampos, listaPalabras, camposOrigen, camposCorregidos) {
    
    let cambiosDetectados = false;
   	for (let i = 0; i < listaPalabras.length; i++) {
        
        let palabraClave = listaPalabras[i];
        
        let campoOrigen = camposOrigen[palabraClave];
        let campoCorregido = camposCorregidos[palabraClave];
        let valorCampoActual = $("#id"+mapaCampos[palabraClave]+"Corregido").val();
        
        if (valorCampoActual !== campoOrigen && valorCampoActual !== campoCorregido) {
            cambiosDetectados = true;
        }
	}
	if(cambiosDetectados) {
		$("#btnGuardarSinAviso").addClass("d-none");
		$("#btnGuardarConAviso").removeClass("d-none");
	} else {
		$("#btnGuardarConAviso").addClass("d-none");
		$("#btnGuardarSinAviso").removeClass("d-none");
	}
}

function toggleConfirmarRechazo(event) {
	event.preventDefault();
	$('#modalConfirmarRechazoInsc').modal({
    		backdrop: 'static',
    		keyboard: false
    	}).css({'padding-right':'10%'});
}

function confirmarRechazo(event) {
	event.preventDefault();
	$('#btnRechazo').click();
}

function cancelarRechazo(event) {
	event.preventDefault();
	$('#modalConfirmarRechazoInsc').modal('toggle');
	return false;
}

function toggleConfirmarGuardado(event) {
	event.preventDefault();
	$('#modalConfirmarGuardado').modal({
    		backdrop: 'static',
    		keyboard: false
    	}).css({'padding-right':'10%'});
}

function confirmarGuardado(event) {
	event.preventDefault();
	$('#btnGuardado').click();
}

function cancelarGuardado(event) {
	event.preventDefault();
	$('#modalConfirmarGuardado').modal('toggle');
	return false;
}


// Función que compara el valor de dos campos y cambia el color de fondo si son iguales
function compararYResaltar(campoOriginal, campoCorregido) {
    // Obtener los elementos por sus IDs
    const campo1 = $('#' + campoOriginal).val();
    const campo2 = $('#' + campoCorregido).val();

    // Comparar los valores de los campos
    if (campo1 === campo2) {		
        // Cambiar el color de fondo a amarillo si son iguales
        $('#' + campoCorregido).css("background-color", "white");        
    } else {		
        // Restablecer el color de fondo si no son iguales
        $('#' + campoCorregido).css("background-color", "lightyellow");
    }
    
}

function activarGuardado() {
	const ids = [
	    'Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 
	    'FechaMatrimonio', 'Nombre1', 'Apellido11', 
	    'Apellido21', 'Fecha1', 'Pais1', 'Provincia1', 
	    'Municipio1', 'Nombre2', 'Apellido12', 
	    'Apellido22', 'Fecha2', 'Pais2', 'Provincia2', 
	    'Municipio2', 'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'
	];

	// Metodo para simplificar implementación de IDs
    ids.forEach(id => {
//        const valorOriginal = $(`#id${id}`).val();
//        $('#' +'wwgrp_' +`id${id}Corregido`).show();
		valoresOriginales[id] = $(`#id${id}Corregido`).val();
        $(`#id${id}Corregido`).attr('disabled', false);
		compararYResaltar(`id${id}`, `id${id}Corregido`);
    });
    
//    $("div.entradaFechaBajo > input#idFechaMatrimonioCorregido").parent().show();
//    $("div.entradaFechaBajo > input#idFecha1Corregido").parent().show();
//    $("div.entradaFechaBajo > input#idFecha2Corregido").parent().show();
	
	$('#divBotonAcciones').addClass("d-none");
	$('#divBotonGuardar').removeClass("d-none");
	
	return false;
}

function desactivarGuardado() {
	const ids = [
	    'Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 
	    'FechaMatrimonio', 'Nombre1', 'Apellido11', 
	    'Apellido21', 'Fecha1', 'Pais1', 'Provincia1', 
	    'Municipio1', 'Nombre2', 'Apellido12', 
	    'Apellido22', 'Fecha2', 'Pais2', 'Provincia2', 
	    'Municipio2', 'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'
	];

	// Metodo para simplificar implementación de IDs
    ids.forEach(id => {
//        const valorOriginal = $(`#id${id}`).val();
//        $('#' +'wwgrp_' +`id${id}Corregido`).hide();
		$(`#id${id}Corregido`).val(valoresOriginales[id]);
        $(`#id${id}Corregido`).attr('disabled', true);
		compararYResaltarDesactivado(`id${id}`, `id${id}Corregido`);
    });
    
//    $("div.entradaFechaBajo > input#idFechaMatrimonioCorregido").parent().hide();
//    $("div.entradaFechaBajo > input#idFecha1Corregido").parent().hide();
//    $("div.entradaFechaBajo > input#idFecha2Corregido").parent().hide();
    
	$('#divBotonAcciones').removeClass("d-none");
	$('#divBotonGuardar').addClass("d-none");
	
	return false;
}

function compararYResaltarDesactivado(campoOriginal, campoCorregido) {
	// Obtener los elementos por sus IDs
    const campo1 = $('#' + campoOriginal).val();
    const campo2 = $('#' + campoCorregido).val();

    // Comparar los valores de los campos
    if (campo1 === campo2) {		
        // Cambiar el color de fondo a amarillo si son iguales
        $('#' + campoCorregido).css("background-color", "whitesmoke");        
    } else {		
        // Restablecer el color de fondo si no son iguales
        $('#' + campoCorregido).css("background-color", "lightyellow");
    }
}

function desactivarGuardadoInicial() {
	const ids = [
	    'Pagina', 'Bis', 'Vuelta', 'TipoInscripcion', 
	    'FechaMatrimonio', 'Nombre1', 'Apellido11', 
	    'Apellido21', 'Fecha1', 'Pais1', 'Provincia1', 
	    'Municipio1', 'Nombre2', 'Apellido12', 
	    'Apellido22', 'Fecha2', 'Pais2', 'Provincia2', 
	    'Municipio2', 'ImagenNoCorresponde', 'ImagenFaltaDatos', 'ImagenLugarIncorrecto'
	];

    ids.forEach(id => {

		$(`#id${id}Corregido`).attr('disabled', true);
		compararYResaltarDesactivado(`id${id}`, `id${id}Corregido`);
		
		// Obtener el elemento correspondiente a la ID
		const elementCorregido = document.getElementById(`id${id}Corregido`);
		
		// Verificar si el elemento no es un checkbox antes de agregar el listener
		if (elementCorregido.type !== 'checkbox') {

			// Forzar mayusculas
			document.getElementById(`id${id}`).addEventListener('input', function() {
				this.value = this.value.toUpperCase()
			});

			document.getElementById(`id${id}Corregido`).addEventListener('input', function() {
				this.value = this.value.toUpperCase()
			});

		}
    });
    
	$('#divBotonAcciones').removeClass("d-none");
	$('#divBotonGuardar').addClass("d-none");
	
	comprobarChecks();

	return false;
}

function comprobarChecks() {
	const dMatVOCorregidoErrNoCorresponde = document.getElementById('idImagenNoCorrespondeHidden');
	const dMatVOCorregidoErrFaltaDatos = document.getElementById('idImagenFaltaDatosHidden');
	const dMatVOCorregidoErrLugarIncorrecto = document.getElementById('idImagenLugarIncorrectoHidden')
	
	const checkboxNoCorresponde = document.getElementById('idImagenNoCorrespondeCorregido');
	const checkboxFaltaDatos = document.getElementById('idImagenFaltaDatosCorregido');
	const checkboxLugarIncorrecto = document.getElementById('idImagenLugarIncorrectoCorregido')
	
	if (dMatVOCorregidoErrNoCorresponde.value === 'true') {
	  checkboxNoCorresponde.checked = true;
	}
	
	if (dMatVOCorregidoErrFaltaDatos.value === 'true') {
	  checkboxFaltaDatos.checked = true;
	}
	
	if (dMatVOCorregidoErrLugarIncorrecto.value === 'true') {
	  checkboxLugarIncorrecto.checked = true;
	}

}